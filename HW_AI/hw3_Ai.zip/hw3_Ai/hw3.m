a=readtable('housedata.csv');
train_data=a(1:700,:); %train
test=a(701:end,:);     %test
x=train_data(:,1:10); %input
y=train_data(:,11); %output
x=table2array(x);   
y=table2array(y);
x=x';
y=y';
net=feedforwardnet([5 3 2]);
net.trainParam.goal=0.001;
net.divideFcn="";
net1=train(net,x,y);
view(net)

weight=net1.IW;
bais=net1.b;
table=[weight bais];
table=array2table(table);
disp(table);


x1=test(:,1:10); %input
y1=test(:,11); %output
x1=table2array(x1);   
y1=table2array(y1);
x1=x1'; y1=y1';
num=round(net1(x1));
disp('accuracy: ');
disp((sum(num==y1)/299)*100);

