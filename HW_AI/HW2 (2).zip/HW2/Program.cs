﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
namespace HW2
{
    class Program
    {
        static void Main(string[] args)
        {
          
            Console.Write("Enter the weight  : ");
            string [] input1= Console.ReadLine().Split(' ');
            Console.Write("Enter the value : ");
            string [] input2 = Console.ReadLine().Split(' ');
            int[] weight = new int[input1.Length];
            int[] value = new int[input2.Length];

            for (int i=0; i < input1.Length; i++)
            {
                  weight[i]= int.Parse(input1[i]);
            }
            
            for (int i = 0; i < input2.Length; i++)
            {
                value[i] = int.Parse(input2[i]);
            }
            
            Console.Write("Enter total weight : ");
            int total = Convert.ToInt32(Console.ReadLine());

            hill_climbing(weight, value, total);

        }

        static void hill_climbing(int[] weight, int[] value, int total)
        {
            int size = weight.Length,total_weight=0,total_value=0,total_weight_current=0, total_value_current = 0;
            List<int> initial = new List<int>();
            Random random = new Random();
            int time = 20000;
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            
            while (stopwatch.ElapsedMilliseconds < time)
            {
                List<int> current = new List<int>(initial);
            check: int randomIndex = random.Next(0, size);
                //Console.Write(weight[randomIndex]);
                if (!current.Contains(randomIndex) && !initial.Contains(randomIndex))
                {
                    current.Add(randomIndex);
                }
                else
                {
                    current.Remove(randomIndex);
                    goto check;
                }
                
                    total_weight_current += weight[randomIndex];
                    total_value_current += value[randomIndex];
                    if (total_weight_current <= total)
                    {
                        if ( total_weight <= total_weight_current && total_weight <= total)
                        {
                            initial = current;
                            total_weight = total_weight_current;
                            total_value = total_value_current;
                        }

                        if ( total_weight == total_weight_current && total_weight <= total)
                        {
                            if (total_value_current > total_value)
                            {
                                initial = current;
                                total_weight = total_weight_current;
                                total_value = total_value_current;
                            }
                        }
                        if (total_value == total_value_current && total_weight <= total)
                        {
                             if (total_weight_current < total_weight)
                             {
                                initial = current;
                                total_weight = total_weight_current;
                                total_value = total_value_current;
                             }

                        }
                    if (total_weight_current > total)
                    {
                        current.Remove(randomIndex);
                        total_weight_current -= weight[randomIndex];
                        total_value_current -= value[randomIndex];
                        goto check;
                    }
                    if (total_weight == total)
                    {
                        break;
                    }
                }
               
            }
            stopwatch.Stop();
            for (int i=0; i < initial.Count; i++)
            {
                Console.Write(initial[i]);
                Console.Write(" ");
            }
            Console.WriteLine();
            Console.WriteLine(total_weight);
            Console.WriteLine(total_value);


        }
    }
}
