﻿using System;
using System.Collections.Generic;

namespace Program
{
    internal class Program
    {
        static int[] Goal = new int[9] {0, 1, 2, 4, 4, 5, 5, 5, 8};
        static void Print(int [] p)
        {
            int index = 0;
            for(int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (p[index] == 0)
                        Console.Write("  ");
                    else Console.Write(p[index] + " ");
                    index++;
                }
                Console.WriteLine();
            }
            Console.WriteLine();
        } 
        class State
        {
            public List<State> Child = new List<State>();
            public State Parent;
            private int[] puzzel = new int[9];
            public int H = 0;
            public int  col = 3; 
            string action = "";

            public string Action { get => action; set => action = value; }
            public int[] Puzzel { get => puzzel; set => puzzel = value; }

            public void setPuzzel(int[] puzzel)
            {
                for (int i = 0; i < puzzel.Length; i++)
                {
                    this.puzzel[i] = puzzel[i];
                }
            }
            public void NumHeuirstic()
            {
                for (int i = 0; i < puzzel.Length; i++)
                {
                    if (puzzel[i] != Goal[i])
                    {
                        H++;
                    }
                }
            }
            public State(int[] p)
            {
                setPuzzel(p);
                //Puzzel(p);
                NumHeuirstic();
            }
            public void copy(int[] p1, int[] p2)
            {
                for (int i = 0; i < p2.Length; i++)
                {
                    p1[i] = p2[i];
                }
            }
            public void Right(int[] p, int i)
            {
                if (i % col < col - 1)
                {
                    int[] p1 = new int[9];
                    copy(p1, p);
                    int temp = p1[i + 1];
                    p1[i + 1] = p1[i];
                    p1[i] = temp;
                    State ch = new State(p1);
                    Child.Add(ch);
                    ch.Parent = this;
                    ch.action = "Right";

                }
            }
            public void Left(int[] p, int i)
            {
                if (i % col > 0)
                {
                    int[] p1 = new int[9];
                    copy(p1, p);
                    int temp = p1[i - 1];
                    p1[i - 1] = p1[i];
                    p1[i] = temp;
                    State chid = new State(p1);
                    Child.Add(chid);
                    chid.Parent = this;
                    chid.action = "Left";
                }
            }
            public void Up(int[] p, int i)
            {
                if (i - col >= 0)
                {
                    int[] p1 = new int[9];
                    copy(p1, p);
                    int temp = p1[i - 3];
                    p1[i - 3] = p1[i];
                    p1[i] = temp;
                    State ch = new State(p1);
                    Child.Add(ch);
                    ch.Parent = this;
                    ch.action = "UP";

                }
            }
            public void Down(int[] p, int i)
            {
                if (i + col < puzzel.Length)
                {
                    int[] p1 = new int[9];
                    copy(p1, p);
                    int temp = p1[i + 3];
                    p1[i + 3] = p1[i];
                    p1[i] = temp;
                    State ch = new State(p1);
                    Child.Add(ch);
                    ch.Parent = this;
                    ch.action = "Down";

                }
            }
            public void expand()
            {
                for (int i = 0; i < puzzel.Length; i++)
                {
                    if (puzzel != Goal)
                    {
                        if (puzzel[i] == 0)
                        {
                            Up(puzzel, i);
                            Down(puzzel, i);
                            Right(puzzel, i);
                            Left(puzzel, i);
                        }
                    }
                    else break;
                }
            }
            public bool IsGoal()
            {
                bool Flag = true;
                if (H != 0)
                {
                    Flag = false;
                }
               return Flag;
            }
        }
        class GreedyFirst 
        {
            List<State> PathSolution = new List<State>();
            List<State> generated = new List<State>();
            List<State> expanded = new List<State>();
            public List<State> Search(State initial)
            {    
                generated.Add(initial);
                if(initial.H!=0)
                expanded.Add(initial);
                initial.expand();
                bool isgoal = false;
                int Hmin = 8;
                State CurrentCh = null;

                while (!isgoal && initial.H!=0)
                {
                    foreach (State ch in initial.Child)
                    {
                        generated.Add(ch);
                        if (Hmin > ch.H)
                        {
                            Hmin = ch.H;
                            CurrentCh = ch;
                        }
                    }
                    if (CurrentCh != null)
                    {
                        if (CurrentCh.IsGoal())
                        {
                            isgoal = true;
                            PathSolution.Add(CurrentCh);
                            while (CurrentCh != null)
                            {
                                CurrentCh = CurrentCh.Parent;
                                PathSolution.Add(CurrentCh);
                            }
                        }
                        else
                        {
                            
                            initial = CurrentCh;
                            initial.expand();
                            expanded.Add(initial);
                            Hmin = 8;
                        }
                    }
                }

                return PathSolution;
            }
            public void Print()
            {
                Console.WriteLine("Number of Generated : {0} ", generated.Count);
                Console.WriteLine("Number of Expanded : {0}", expanded.Count);
            }
        }
        static void Main(string[] args)
        {
            int[] puzzel = new int[9];
            string inital = "";
            Console.Write("Enter the inital state : ");
            inital = Console.ReadLine();

           for (int i = 0; i < inital.Length; i++)
            {
                if (inital[i] == 'S')
                    puzzel[i] = 0;
                else
                    puzzel[i] = int.Parse(inital[i].ToString());
            }
            Console.WriteLine();

            Console.WriteLine("Initial State :");
            Print(puzzel);

            State InitalState = new State(puzzel);
            GreedyFirst State = new GreedyFirst();
            List<State> Path_Solution = State.Search(InitalState);

            Console.WriteLine("Goal State :");
            Print(Goal);

            Console.Write("The action goal: ");
            if (Path_Solution != null)
            {
                Path_Solution.Reverse();
                for (int i = 0; i < Path_Solution.Count; i++)
                {
                    if (Path_Solution[i] != null)
                        Console.WriteLine(Path_Solution[i].Action);
                }
                Console.WriteLine();
                State.Print();
            }
            else
            {
                Console.WriteLine("No path to  solution is found..");
            }
        }
    }
}